package br.edu.fapi.pinhais.excecoes.ex02;

public class VerificarNome implements VerificarNomeInterface {

	@Override
	public void checarNome(String nome) throws NomeInvalidoException {
		if (nome.startsWith("_")) 
		{
			throw new NomeInvalidoException(nome);
		}
		
	}

}
