package br.edu.fapi.pinhais.excecoes.ex02;

public class NomeInvalidoException extends Exception {
	
	String nome;
	
		public NomeInvalidoException(String nome) 
		{
			this.nome = nome;
		}
		public String GetName() 
		{
			return nome;
		}
}
