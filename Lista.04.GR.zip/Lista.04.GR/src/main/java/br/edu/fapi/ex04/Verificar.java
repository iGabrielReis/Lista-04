package br.edu.fapi.pinhais.excecoes.ex04;

public interface Verificar {

	void verificarAresta(int num1, int num2, int num3) throws ArestasInvalidasException;
}
