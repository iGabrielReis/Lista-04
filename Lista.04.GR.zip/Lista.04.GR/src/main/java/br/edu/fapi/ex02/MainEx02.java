package br.edu.fapi.pinhais.excecoes.ex02;

import java.util.Scanner;

public class MainEx02 {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		String nome;
		VerificarNomeInterface verifica = new VerificarNome();
		System.out.println("Digite seu nome: ");
		nome = ler.nextLine();
		try {
			verifica.checarNome(nome);
			System.out.println("Seu nome �: " + nome);
		} catch (NomeInvalidoException ex) {
			System.out.println("Iih deu ruim!! Nome Invalido \n Nome invalido: " + ex.GetName());
		}
	}

}
