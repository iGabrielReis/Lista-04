package br.edu.fapi.pinhais.excecoes.ex04;

import java.util.Scanner;

public class MainEx04 {

	public static void main(String[] args) {

		Scanner ler = new Scanner(System.in);
		Verificador verificar = new Verificador();

		try {
			int num1, num2, num3;

			System.out.println("Digite o 1 comprimentos");
			num1 = ler.nextInt();
			System.out.println("Digite o 2 comprimento");
			num2 = ler.nextInt();
			System.out.println("Digite o 3 comprimento");
			num3 = ler.nextInt();
			verificar.verificarAresta(num1, num2, num3);

		} catch (ArestasInvalidasException ex) {
			System.out.println("Valores informados n�o formam um tri�ngulo" + ex);

		}

	}

}
