package br.edu.fapi.pinhais.excecoes.ex04;

public class ArestasInvalidasException extends Exception {

	public ArestasInvalidasException(int n1, int n2, int n3) {
		super();
	}
}
