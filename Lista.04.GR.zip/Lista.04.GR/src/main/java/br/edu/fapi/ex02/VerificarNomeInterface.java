package br.edu.fapi.pinhais.excecoes.ex02;

public interface VerificarNomeInterface {
	
	public void checarNome(String nome) throws NomeInvalidoException;

}
